🇺🇸
This project is done by Shaxobiddin and Fakhrullo to demonstrate faceswapping.
This is for study purposes only and do not use it for bad reasons.
The main focus of this project is to pass the assignment.

🇺🇿
Ushbu loyiha Shaxobiddin va Faxrullo tomonidan yuz almashtirishni ko'rsatish uchun amalga oshirilgan.
Bu faqat o'rganish uchun mo'ljallangan va uni yomon sabablarga ko'ra ishlatmang.
Ushbu loyihaning asosiy maqsadi yakuniy imtihonni topshirishdir.