#!/usr/bin/env python3

from root_folder import core

if __name__ == '__main__':
    core.run()
